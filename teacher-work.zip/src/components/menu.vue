<template>
    <nav class="bg-white wrap clearfix" id="menu">
        <div class="gn-sec-nav">
            <a href="javascript:void(0);" target="_self" @click="selectClick('index')"><span class="on" data-type="index">首页</span></a>
            <a href="javascript:void(0);" target="_self" @click="selectClick('trend')"><span data-type="index">动态</span></a>
            <a href="javascript:void(0);" target="_self" @click="selectClick('lesson')"><span class="" data-type="course">课程</span></a>
            <a href="javascript:void(0);" target="_self" @click="selectClick('articles')"><span  data-type="blog">文章</span></a>
            <a href="javascript:void(0);" target="_self" @click="selectClick('wt')"><span data-type="blog">委托</span></a>
            <a href="javascript:void(0);" target="_self" @click="selectClick('shifan')"><span data-type="aplan">示范账户</span></a>
        </div>
        <div class="gn-sec-line"></div>
        <div class="gn-sec-div">
            <a href="javascript:void(0)" class="gn-more-btn"></a>
            <!-- <a href="javascript:void(0)" class="gn-left-btn"></a> -->
        </div>
    </nav>
</template>

<script>
    export default {
        name: "tag",
        data:function(){
            return {
                menuData:[],
                type:this.workType,
                vues: {
                    'index': 'Home',
                    'lesson': 'Lesson',
                    'trend': 'Trend',
                    'shifan': 'ShiFan',
                    'wt': 'WeiTuo',
                    'articles': 'Article'
                }
            }
        },
        props:{
            workType:{type:String,default:'index'}
        },
        created(){
        },
        watch: {
            'type':function(_v,_ov){
                console.log('选修卡加载完毕:type',_v,_ov)
                this.selectClick(_v);
            },
            'workType':function(_v,_ov){
                console.log('选修卡加载完毕:workType',_v,_ov)
                this.type=_v;
            },
        },
        mounted(){
            console.log('挂着完毕：',this)
            this.selectClick(this.type);
            this.$getData('tag',{partnerId:this.$getTechId});
            // this.$getData('wzList',{tid:this.$getTechId,page:1,pagesize:12},false)
        },
        activated(){
        },
        deactivated(){
        },
        methods:{
            selectClick:function(e){
                e=e||'index';
                this.$emit('type',this.vues[e])
            }
        }
    }
</script>

<style scoped>

    #menu{
        margin-bottom: 2.5px;
    }
    #menu a.gn-more-btn,#menu a.gn-left-btn{
        display:inline-block;
        padding:0;
        margin-top:18px;
        margin-left:14px;
        width: 18px;
        height: 18px;
        background:url(../assets/images/gn-icos.png) no-repeat 0 0rem/1.6rem 26.8rem;
    }
    #menu a.gn-left-btn{
        background-position: 0 -1.6rem;
        background-size: 1.6rem 26.8rem;
    }

    #menu{box-sizing: border-box;margin-bottom: 10px;padding: 0;}
    #menu a{display: inline-block;line-height: 50px;text-align: center;padding: 0 5%;}
    #menu a span{display: inline-block;line-height: 50px;}
    #menu a span.on{color: #ee5050;border-bottom:1px solid #ee5050;}
    #menu{
        margin-bottom: 2.5px;
    }
    #menu a.gn-more-btn,#menu a.gn-left-btn{
        display:inline-block;
        padding:0;
        margin-top:18px;
        margin-left:14px;
        width: 18px;
        height: 18px;
        background:url(../assets/images/gn-icos.png) no-repeat 0 0rem/1.6rem 26.8rem;
    }
    #menu a.gn-left-btn{
        background-position: 0 -1.6rem;
        background-size: 1.6rem 26.8rem;
    }
</style>