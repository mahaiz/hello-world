<!--工作室文章标签:显示文字列表-->
<template>
    
</template>

<script>
    export default {
        name: "article"
    }
</script>

<style scoped>
    .loading{
        width: 100%;
        height: 35px;
        line-height: 35px;
        text-align: center;
        display: none;
        position: fixed;
        bottom: 0;
        left: 0;
        background: #fff;
    }
    .loading img{
        width: 30px;
        height: 30px;
    }

    /*文章列表*/
    .articleList{padding:5px 15px 10px 15px;box-sizing: border-box;margin-top: 10px;background: #fff;}
    .articleList h5{font-size: 16px;line-height: 40px;width: 100%;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;box-sizing: border-box;position: relative;}
    .articleList span.tag{display: block;position: absolute;right: 0px;top: 8px;color: #ee5050;text-align: center;line-height: 27px;border-radius: 25px;border:#ee5050 solid 1px;font-size: 12px;padding: 0 6px;}
    .articleList p{
        line-height:21px;
        font-size: 14px;
        color: #666;
    }
    .articleList p a{
        color: #666;
    }
    .articleList .clamp{
        position:relative;
        line-height:21px;
        /* 3 times the line-height to show 3 lines */
        height:42px;
        overflow:hidden;
        font-size: 14px;
    }
    .articleList .clamp::after {
        content:"...";
        font-weight:bold;
        position:absolute;
        bottom:0;
        right:0;
        padding:0 20px 1px 45px;
        background:url(https://css88.b0.upaiyun.com/css88/2014/09/ellipsis_bg.png) repeat-y;
    }
    .articleList .readCount{vertical-align: top;}
    .articleList .readCount i,.articleList .readCount span{display: block;float: left;}
    .articleList .readCount i{background: url(../images/icos.png) no-repeat 0 -254px;background-size:25px;margin-top: 1px;}
    .articleList .readCount span{padding: 0 10px 0px 6px;vertical-align: middle;height: 12px;line-height: 12px;overflow:hidden;}
    .articleList .readCount span.read{padding-right: 0px;}
    .articleList .readCount i.pl-ico{width: 13px;height: 11px;}
    .articleList .readCount i.read-ico{width: 14px;height: 11px;background-position: 0 -270px;}

    /*文章趋势分析 s*/
    .lkdiv{
        display: inline-block;
        margin-right: 20px;
        padding-bottom:10px;
        font-size:14px;
    }
    .lkdiv i{
        display: inline-block;
        width: 16px;
        height: 15px;
        margin-top: 3px;
        margin-left: 5px;
        vertical-align: top;
    }
    .lkdiv i.c-up-red{
        background: url(//imgcd.hexun.com/images/lh-icos.png) no-repeat 0 0;
    }
    .lkdiv i.c-up-gray{
        background: url(//imgcd.hexun.com/images/lh-icos.png) no-repeat 0 -19px;
    }
    .lkdiv i.c-right-orange{
        background: url(//imgcd.hexun.com/images/lh-icos.png) no-repeat 0 -39px;
    }
    .lkdiv i.c-right-gray{
        background: url(//imgcd.hexun.com/images/lh-icos.png) no-repeat 0 -59px;
    }
    .lkdiv i.c-down-green{
        background: url(//imgcd.hexun.com/images/lh-icos.png) no-repeat 0 -79px;
    }
    .lkdiv i.c-down-gray{
        background: url(//imgcd.hexun.com/images/lh-icos.png) no-repeat 0 -99px;
    }

    .c-lk-green{color: #0DB566}
    .c-lk-orange{
        color: #FF9817;
    }
    .c-lk-red{
        color: #ee5050;
    }
/*文章趋势分析 e*/
</style>