<!--工作室主结构:老师介绍-->
<template>
    <div>
        <section class="bg-blue wrap" id="teacherInfo">
            <div class="lef"><img :src="photo"></div>
            <div class="mid white">
                <h5><span class="ft16">{{partnerData.truename}}</span><i class="tg"></i></h5>
                <dl class="clearfix jg infoHide" :style="`display:${partnerLevel===1?'block':'none'}`">
                    <dt></dt>
                    <dd>所在机构：{{partnerData.orgname}}</dd>
                </dl>
            </div>
            <div class="rig"><a class="attend e4c" data-flog="0" @click="test0">已关注</a></div>
        </section>
        <!--介绍 s-->
        <section class="bg-blue wrap infoHide" style="display: block;">
            <dl class="clearfix zgh" :style="`display:${partnerLevel===1?'block':'none'}`">
                <dt class="two"></dt>
                <dd>证券执业资格号：{{partnerData.jobCode}}</dd>
            </dl>
            <p class="tag sc"><b>擅长：</b><span>专注短线</span><span>操盘高手</span><span>涨停板王</span></p>
            <p class="infoTxt" :title="partnerData.intro">简介：{{partnerData.intro}}</p>

        </section>
        <div class="bg-blue gn-navcon">
            <ul class="gn-nav clearfix">
                <li class="gn-left">
                    <span>{{fansCount}}<i v-show="fansCount.toString().indexOf('.')>0">万</i></span>
                    <p>粉丝数</p>
                </li>
                <li>
                    <span>2504</span>
                    <p>问股回答</p>
                </li>
                <li>
                    <span>829</span>
                    <p>发布文章</p>
                </li>
                <li class="gn-right">
                    <span>28</span>
                    <p>发布课程</p>
                </li>
            </ul>
        </div>
        <p class="bg-blue arrowB"><a class="arrow arrowUp"></a></p>
        <!--介绍 e-->
        <Menu @type="test" :workType="workType"></Menu>
        <div class="content">
            <div id="loading" :style="{display: loaded?'block':'none'}">
                <img src="//imgcd.hexun.com/teacher/h5/images/loading.gif" alt="">
            </div>
            <keep-alive>
                <component v-bind:is="currentTabComponent" @loaded="onLoaded"></component>
            </keep-alive>
        </div>
        <!--关注提示框-->
        <div class="gztsBox">
            <div class="gzts">
                <h4>确定要取消对<span></span>的关注吗？</h4>
                <div>
                    <a href="javascript:void(0);" class="yes fl">是</a>
                    <a href="javascript:void(0);" class="fou fl">否</a>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import Menu from './menu';
    export default {
        name: "index",
        data:function(){
            return {
                currentTabComponent:'',
                http:this.$getHttpToHttps,
                loaded:true,
                loginInfo:this.$getLoginInfo,
                workType:this.$getWorkType,
                partnerData:{},
                selecttag:[],
                photo:'',
                partnerLevel:0,// 身份  1是投顾，2是培训师，3是直播人
                fansCount:0//粉丝数
            }
        },
        created(){
            // 'zhicheng','fans','tag'
            var _this=this;
            this.$getAllData([{'zhicheng':{partnerId:this.$getTechId}},{'fans':{uid:this.$getTechId}}]).then(function([zhicheng,fans]){
                console.log("zhicheng,fans,tag=",zhicheng,fans,_this);
                if(zhicheng && zhicheng.resultKey==='ok'){
                    _this.partnerData=zhicheng.data.data.Partner;
                    _this.selecttag=zhicheng.data.data.selecttag;
                    _this.partnerLevel=zhicheng.data.data.partnerLevel;
                    _this.photo=zhicheng.data.data.photo;
                }


                _this.fansCount=fans.statecode==='1'?fans.result.fansCount:0;
                if(_this.fansCount>10000)_this.fansCount=(_this.fansCount/10000).toFixed(2);
                console.log('_this.partnerData=',_this.partnerData)
            })
        },
        watch: {
            'http': function (_v, _ov) {
                console.log('test：', _v, _ov)
            },
            'loginInfo':function(_v, _ov){
                console.log('加载用户信息',_v,_ov)
            }
        },
        methods: {
            test0:function(){
                this.workType='lesson'
            },
            test: function (e) {
                console.log('加载首页',e);
                this.currentTabComponent=e||'Home';
            },
            onLoaded:function(){
                this.loaded=false;
            }
        },
        components:{
            Menu,
            /*Home: () => ({
                // 需要加载的组件 (应该是一个 `Promise` 对象)
                component: import('./home'),
                // 异步组件加载时使用的组件
                loading: Loading,
                /!*!// 加载失败时使用的组件
                error: ErrorComponent,
                // 展示加载时组件的延时时间。默认值是 200 (毫秒)
                delay: 200,
                // 如果提供了超时时间且组件加载也超时了，
                // 则使用加载失败时使用的组件。默认值是：`Infinity`
                timeout: 3000*!/
            })*/
            Home:function(resolve){
                import('./home').then(function(_d){
                    resolve(_d);
                })
            }
        }
    }
</script>

<style>/*首页*/
.wrap{padding: 0 15px;box-sizing: border-box;}
.wrapL15{padding: 0 0 0 	15px;box-sizing: border-box;}
.bg-blue{ background: #142f5c;}
.bg-white{ background: #fff;}
.bg-ee{ background: #eee;}

    /*关注提示弹窗*/
    .gztsBox{
        width: 100%;
        height: 100%;
        position: fixed;
        background: rgba(0,0,0,.5);
        z-index: 998;
        display: none;
    }
    .gzts{
        position: absolute;
        width: 72%;
        left: 14%;
        top: 35%;
        border-radius: 10px;
        background: #fff;
        font-size: 16px;
    }
    .gzts h4{
        color: #000;
        text-align: center;
        line-height:20px;
        padding: 25px;
        box-sizing: border-box;
    }
    .gzts div{
        width: 100%;
        overflow: hidden;
        text-align: center;
        border-top: 1px solid #D3D3D7;
    }
    .gzts div a{
        line-height: 40px;
    }
    .gzts div a.yes{
        width: 49%;
        border-right: 1px solid #d3d3d7;
        color:#0074ff;
    }.gzts div a.fou{
         width:50%;
         color: #ee5050;
     }
    #teacherInfo{box-sizing:border-box;position: relative;height:84px;}
    #teacherInfo .lef,#teacherInfo .rig{position: absolute;top:12px;}
    #teacherInfo .lef{left:15px;width:56px;height:56px;border-radius: 999px;border:#8c9ab3 solid 2px;overflow: hidden;}
    #teacherInfo .lef img{width:56px;height:56px;}
    #teacherInfo .rig{right: 15px;}
    #teacherInfo .rig a{display: block;width: 90px;height: 35px;line-height: 35px;border-radius:25px;text-align: center;color: #fff;margin-top: 15px;}
    #teacherInfo .rig a.e50{
        background: #EE5050;
    }
    #teacherInfo .rig a.e4c{
        background: #3c4c6c;
    }
    #teacherInfo .mid{padding: 12px 90px 0 69px;}
    #teacherInfo .mid i{display: inline-block;width: 16px;height: 16px;margin:2px 0 0 10px;background: url(../assets/images/icos.png) no-repeat 0 -87px; background-size:25px;vertical-align: top;}
    #teacherInfo .mid i.mj{background-position: 0 -68px;display: none;}
    #teacherInfo .mid i.ls{background-position: 0 -87px;display: none;}
    #teacherInfo .mid i.tg{background-position: 0 -328px;display: none;}
    #teacherInfo .mid h5{padding-top: 10px;vertical-align: top;}
    .infoHide{color: #a2aec1;padding-bottom: 10px;display: none;}
    .infoHide dl{padding-bottom: 10px;}
    .infoHide dl dt,.infoHide dl dd{float: left;line-height: 14px;}
    .infoHide dl dt{width: 12px;height: 14px;background: url(../assets/images/icos.png) no-repeat 0 -129px; background-size:25px;margin-right: 10px;}
    .infoHide dl dt.two{width: 14px;height: 11px; background-position: 0 -149px;    margin-top: 3px;}
    .infoHide .tag b,.infoHide .tag span{display: inline-block;}
    .infoHide .tag span{
        padding: 0 10px;
        height: 24px;
        line-height: 24px;
        border-radius:4px;
        background: rgba(255,255,255, 0.1);
        text-align: center;
        color: #bec4cf;
        margin: 5px 10px 5px 0;
    }
    .infoHide .infoTxt{line-height: 24px;padding-top: 5px;}
    .mask,.mask2,.mask-attend,.mask-edit{display:none;background:rgba(0,0,0,0.7);width: 100%;height: 100%;position: fixed;top: 0px;left:0px;z-index: 998;}
    .arrowB{padding-bottom: 10px;text-align: center;}
    .mask iframe,.mask2 iframe{ z-index: 998; width: 100%; height: 100%; background: none;border:0; }
    .arrowB a{display: inline-block;border-right:solid 2px #fff;border-top:solid 2px #fff;width: 10px;height: 10px;-webkit-transform:rotate(135deg);-webkit-transition:ease-in 0.2s;}
    .arrowB a.arrowUp{-webkit-transform: rotate(-45deg);transition:ease-in 0.2s;margin-bottom: -7px;}

    .disnone{
        display: none;
    }
    .disblock{
        display: block;
    }
    .bb88 {
        color: #44bb88;
    }
    .ee5050 {
        color: #ee5050;
    }
    #loading{
        text-align: center;
        padding: 50px 0;
        vertical-align: middle;
    }
    #loading img{
        width: 32px;
        height: 32px;
    }

    /*20181220  TinaGao -s*/


    .gn-a-more{
        font:14px/24px 'microsoft yahei';
        color: #a2aec1;
    }
    .gn-navcon{
        width:90%;
        padding:0 5%;
    }
    .gn-nav{
        width:100%;
        padding:10px 0 5px;
        border-top:solid 1px rgba(255,255,255,0.20);
    }
    .gn-nav li{
        float: left;
        width:25%;
        color:#fff;
        text-align: center;
    }
    .gn-nav li span{
        font-size: 16px;
        font-family: 'arial';
        color:#fff;
    }
    .gn-nav li span i{
        font-size:12px;
    }
    .gn-nav li p{
        font-size:14px;
        opacity: .7;
    }
    .gn-sec-nav{
        white-space: nowrap;
        overflow: hidden;
        float: left;
        width:85%;
    }
    .gn-sec-line{
        float: left;
        width:2%;
        height: 50px;
        overflow: hidden;
        background: -webkit-linear-gradient(-90deg, rgba(255,255,255,0.00) 0%, rgba(0,0,0,0.06) 100%);
        background: linear-gradient(-90deg, rgba(255,255,255,0.00) 0%, rgba(0,0,0,0.06) 100%);
    }

    .gn-sec-div{
        float: right;
        width: 13%;
        text-align: center;
    }
.gn-a-more{
    font:14px/24px 'microsoft yahei';
    color: #a2aec1;
}
.gn-navcon{
    width:90%;
    padding:0 5%;
}
.gn-nav{
    width:100%;
    padding:10px 0 5px;
    border-top:solid 1px rgba(255,255,255,0.20);
}
.gn-nav li{
    float: left;
    width:25%;
    color:#fff;
    text-align: center;
}
.gn-nav li span{
    font-size: 16px;
    font-family: 'arial';
    color:#fff;
}
.gn-nav li span i{
    font-size:12px;
}
.gn-nav li p{
    font-size:14px;
    opacity: .7;
}
.gn-sec-nav{
    float: left;
    width:85%;
}
.gn-sec-line{
    float: left;
    width:2%;
    height: 50px;
    overflow: hidden;
    background: -webkit-linear-gradient(-90deg, rgba(255,255,255,0.00) 0%, rgba(0,0,0,0.06) 100%);
    background: linear-gradient(-90deg, rgba(255,255,255,0.00) 0%, rgba(0,0,0,0.06) 100%);
}

.gn-sec-div{
    float: right;
    width: 13%;
    text-align: center;
}
</style>