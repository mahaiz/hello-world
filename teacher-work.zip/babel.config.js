module.exports = {
  presets: [
    // '@vue/app'
   ['@vue/app',{useBuiltIns: 'false'}]
  ]
}
