<!--老师工作室动态标签-->
<template>
    <!-- 暂无最新动态-s -->
    <div id="tab_cont_index" class="tab_cont">
        <div class="noPlayback" style="display: block;">
            <div class="zwnr"></div>
            <p>老师很懒，暂无最新动态</p>
        </div>
    </div>

    <a href="#" class="gn-intozbs"><span></span>直播中，进入直播室</a>
</template>

<script>
    export default {
        name: "trend"
    }
</script>

<style scoped>

    .gn-intozbs{
        position: fixed;
        bottom:0;
        left:0;
        z-index: 10;
        display: block;
        width: 100%;
        height: 50px;
        overflow: hidden;
        font:17px/50px 'microsoft yahei';
        color:#fff;
        text-align: center;
        background: #ee5050;
        vertical-align: top;
    }
    .gn-intozbs span{
        display: inline-block;
        margin-top: 16px;
        margin-right: 8px;
        width: 15px;
        height: 16px;
        vertical-align: top;
        background: url(../images/gn-icos.png) no-repeat 0 -15.4rem/1.4rem 26.8rem;
    }
    /*动态-互动交流列表*/
    .gn-hdjl-div{
        position: relative;
        padding:8px 20px;
        overflow: hidden;
        background: #fff;
        border-bottom:solid 5px #f5f5f5;
    }
    .gn-hd-btn,.gn-xx-btn{
        position: absolute;
        right:20px;
        top:10px;
        display: block;
        width: 54px;
        height: 28px;
        font:14px/28px 'microsoft yahei';
        color: #fff;
        text-align: center;
        background: #199FFD;
        -webkit-border-radius: 100px;
        border-radius: 100px;
    }
    .gn-xx-btn{
        background: #ee5050;
    }
    .gn-hdjl-tit{
        width: 73%;
        height:32px;
        overflow: hidden;
        font:16px/32px 'microsoft yahei';
        color: #333;
        vertical-align: top;
    }
    .gn-hdjl-suo{
        display: inline-block;
        margin-top: 7px;
        margin-left: 6px;
        width: 16px;
        height: 18px;
        vertical-align: top;
        background:url(../images/gn-icos.png) no-repeat 0 -9.7rem/1.6rem 26.8rem;
    }
    .gn-hdjl-inf{
        font-size:14px;
        color: #999;
    }
    .gn-c-time{
        display: inline-block;
        margin-right: 10px;
        font-size:14px;
        vertical-align: top;
    }
    .gn-c-time i{
        display: inline-block;
        margin-right:5px;
        margin-top: 4px;
        width: 14px;
        height: 14px;
        vertical-align: top;
    }
    .gn-c-red{
        color:#EE5050;
    }
    .gn-c-blue,.gn-c-jx{
        color: #1EA2FF;
    }
    .gn-c-yellow{
        color: #FFA800;
    }
    .gn-c-red i{
        background:url(../images/gn-icos.png) no-repeat -.22rem -17.2rem/1.6rem  26.2rem
    }
    .gn-c-blue i{
        background:url(../images/gn-icos.png) no-repeat -.14rem -6.6rem/1.6rem 27.4rem
    }
    .gn-c-yellow i{
        margin-top: 5px;
        background:url(../images/gn-icos.png) no-repeat -.2rem -4.8rem/1.6rem 26rem
    }
    .gn-c-jx i{
        background:url(../images/gn-icos.png) no-repeat -.2rem -3.4rem/1.6rem 26.8rem
    }
    .gn-hdjl-txt{
        margin-top: 3px;
        font-size:14px;
        color: #999;
    }
    .gn-hdjl-other{
        margin-top: 8px;
        width: 100%;
        height:22px;
        overflow: hidden;
    }
    .gn-hdjl-gg{
        display: inline-block;
        margin-right: 10px;
        padding:0 5px;
        font-size: 14px;
        color: #EE5050;
        background: rgba(238,80,80,0.08);
        -webkit-border-radius: 4px;
        border-radius: 4px;
    }
    .gn-hdjl-tab{
        width:100%;
    }
    .gn-hdjl-tab td{
        width: 50%;
        font-size:12px;
        line-height: 200%;
        color: #999;
    }
    .gn-hdjl-tab td span{
        font-size:16px;
    }
    .gn-intojl-btn,.gn-intozbs-btn{
        position: fixed;
        bottom:0;
        left: 0;
        width: 100%;
        height: 50px;
        font:17px/50px 'microsoft yahei';
        color: #fff;
        text-align: center;
        background: #199FFD;
    }
    .gn-intozbs-btn{
        background: #ee5050;
    }
    .gn-intojl-btn i,.gn-intozbs-btn i{
        display: inline-block;
        margin-right: 6px;
        width: 18px;
        height:17px;
        vertical-align: top;
        margin-top: 15px;
        background:url(../images/gn-icos.png) no-repeat 0 -13rem/1.44rem 26rem;
    }
    .gn-intozbs-btn i{
        background-position: 0 -11rem;
    }
    .gn-bd-no{
        border-bottom: 0;
    }
    .gn-act-con{
        width:100%;
        overflow: hidden;
        background: #fff;
    }
    .gn-act-list{
        padding:10px 0;
        width:94%;
        margin:0 auto;
        border-bottom:solid 1px #eee;
    }
    .gn-act-tit{
        width: 100%;
        overflow: hidden;
        font-size:16px;
        color:#333;
        line-height: 30px;
        text-overflow: ellipsis;
    }
    .gn-act-dl01{
        margin-top: 5px;
        width: 100%;
        height: 24px;
        overflow: hidden;
        font-size:14px;
        vertical-align: top;
    }
    .gn-act-dl01 dt{
        float: left;
        width:40%;
        color:#999;
        vertical-align: top;
    }
    .gn-act-dl01 dt span{
        vertical-align: top;
    }
    .gn-sp-suo{
        display: inline-block;
        margin-left: 4px;
        width: 20px;
        height: 24px;
        overflow: hidden;
        background:url(../images/gn-icos.png) no-repeat 0 -7.4rem/1.44rem 26rem;
    }
    .gn-act-dl01 dd{
        float: right;
        width: 60%;
        text-align: right;
    }
    .gn-act-dl01 .lkdiv{margin-right: 0;}
</style>