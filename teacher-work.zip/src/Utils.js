import Jsonp from 'jsonp';
let _isTest=window.location.host.match('test'),
    _host={
        apiLessonHost:"http://"+(_isTest?"test.":"")+"apilesson.hexun.com/",
        followHost:"http://"+(_isTest?"test":"")+"follow.zq.hexun.com/",
        apiZhiboHost:"http://"+(_isTest?"test.":"")+"api.zhibo.hexun.com/",
        zhiboHost:"http://"+(_isTest?"test.":"")+"zhibo.hexun.com/",
        lessonHost:"http://"+(_isTest?"test":"")+"lesson.hexun.com/",
        orderHost:"https://"+(_isTest?"test-":"")+"order.hexun.com/",
        pxHost:"http://"+(_isTest?"test.":"")+"partner.px.hexun.com/",
        cdHost:"http://"+(_isTest?"test.":"")+"caidao.hexun.com/",
        apiCdHost:"http://"+(_isTest?"test.":"")+"apicaidao.hexun.com/",
        match:"http://"+(_isTest?"testapi.match.vip.":"api.match.")+"hexun.com/",
        pl:"http://"+(_isTest?"testcomment.zq.":"comment.zq.")+"hexun.com/",
        callvip:"http://"+(_isTest?"test-callvip.":"callvip.")+"hexun.com/",
        wt:"http://"+(_isTest?"test.weituo.":"weituo.")+"caidao.hexun.com/"
    },
    _interface={
        wt:_host.wt+"public/api/",//委托接口
        getUserInfo:_host.match+"api/account/getUserInfo",//查询用户信息
        regUser:_host.match+"api/account/regUser",//去报名
        initEntrust:_host.match+"api/account/initEntrust",//一键委托
        GetComment:_host.pl+"Comment/GetComment.do?",//获取评论
        praise:_host.pl+"Comment/praise.do?",//评论点赞
        addReportMessage:_host.pl+"ReportMessage/addReportMessage.do?",//评论举报
        PostComment:_host.pl+"Comment/PostComment.do?",//评论发表
        islogin:'https://regtool.hexun.com/wapreg/checklogin.aspx?format=json&encode=no',//是否登录
        zhicheng:_host.pxHost+'api/partner/get_partnershow_info',//获取职称 "partnerLevel": 身份  1是投顾，2是培训师，3是直播人?partnerId=
        followtearch:_host.followHost+'relation/isattention.do',//获取是否关注
        afollowtearch:_host.followHost+'relation/add.do',//关注老师
        qfollowtearch:_host.followHost+'relation/cancel.do',//取关老师
        fans:_host.followHost+'relation/getrelationinfo.do?source=2',//粉丝&uid=
        roomonline:_host.apiZhiboHost+'api/teacher/is_room_online?teacherId=',//是否在线
        roominfo:_host.apiZhiboHost+'api/teacher/room_latest_info?teacherId=',//房间信息
        roomanq:_host.apiZhiboHost+'api/teacher/room_zhibo_info?teacherId=',//房间问答
        adcont:_host.pxHost+'api/partner/query_adversiting_by_id',//第一页签内容
        spzbpage:'http://api.cd.hexun.com/rest/webinar/record-pages?teacherId=',//视频带分页
        spzb:_host.apiLessonHost+'lesson/live',//视频直播
        spkj:_host.apiLessonHost+'lesson/pack',//视频课件
        tjkc:_host.apiLessonHost+'lesson/open',//推荐课程
        openClass:_host.apiLessonHost+'lesson/openandhistory/',//公开课
        lessonkey:_host.apiLessonHost+'api/video/',
        ngspzb:_host.apiLessonHost+'lesson/live',//视频直播
        tag:_host.pxHost+'api/partner/get_navigation_show',//获取老师页签?partnerId=
        wzList:_host.apiCdHost+'article/{tid}/{page}/{pagesize}',//文章列表
        haveZbs:_host.apiZhiboHost+'api/search/query_rooms_by_teacher_id?teacherId=',//判断老师是否有直播室
        buyurl:_host.orderHost+'order/h5/product?',//购买地址
        configures:_host.apiCdHost+'entrust/configures/',//是否显示委托按钮
        entrust:_host.apiCdHost+'entrust/configure/',//是否显示委托按钮
        getuserright:_host.callvip+'jsapi/right/getuserright' ,//是否有委托权限
        getuserr: _host.apiCdHost + 'combination/configures/', //根据老师的id分页获取组合配置信息
        configure: _host.apiCdHost + 'combination/configure/' //根据组合id获取组合配置信息
    },
    _httpToHttps={editHost:function(_u){return _u}},
    _teachID,_workType
    ,_loginInfo={};
let utils={
    install:function(Vue){
        Vue.prototype.$getData = function (urlName,data={},type=true) {
            let _url=_httpToHttps.editHost(_interface[urlName]||'');
            if(type){//url传参
                _url += (_url.indexOf('?') < 0 ? '?' : '&') + utils.param(data);
            }else{//路径传参
                for(let key of Object.keys(data)){
                    _url=_url.replace(`\{${key}\}`,data[key]);
                }
                console.log('url=',_url);
            }

            return new Promise((resolve,reject) => {
                Jsonp(_url, (err, data) => {
                    if (err) {
                        console.error('err=',err.message);
                    } else {
                        // console.log('data=',data);
                        resolve(data);
                    }
                })
            });
        };
        Vue.prototype.$getAllData=function(_arrName=[]){
          let _promise=_arrName.map(function(_item){
              console.log('item=',typeof _item)
              let _urlName=typeof _item =='string'?_item:Object.keys(_item)[0];
              let _data=typeof _item=='string'?{}:Object.values(_item)[0];
              // console.log('_urlName,_data=',_urlName,_data)
              return Vue.prototype.$getData(_urlName,_data)
          });
          return Promise.all(_promise);
        };
        Vue.prototype.$getUrlParam=this.getUrlParam;
        Vue.prototype.$getRealLen=this.getRealLen;
        Vue.prototype.$beautySub=this.beautySub;
        Vue.prototype.$filtimg=this.filtimg;
        Vue.prototype.$getTechId=_teachID;
        Vue.prototype.$getWorkType=_workType;
        Vue.prototype.$getScrollTop=this.getScrollTop;
        Vue.prototype.$getClientHeight=this.getClientHeight;
        Vue.prototype.$getScrollHeight=this.getScrollHeight;

        //用户信息
        Vue.prototype.$getLoginInfo=_loginInfo;
        Vue.prototype.$setLoginInfo=(_o)=>{utils.updateVueData(Vue,_loginInfo,_o)}

        Vue.prototype.$setHttpToHttps=(_o)=>{utils.updateVueData(Vue,_httpToHttps,_o)}
        Vue.prototype.$getHttpToHttps=_httpToHttps;
        Vue.prototype.$host=function(_hostName){return _host[_hostName]||'//caidao.hexun.com/'}

    },
    updateVueData(Vue,_target,_o) {
        for (let key in _o) {
            Vue.set(_target, key, _o[key]);
        }
    },
    param(data) {
        let url = ''
        for (var k in data) {
            let value = data[k] !== undefined ? data[k] : ''
            url += `&${k}=${encodeURIComponent(value)}`
        }
        // 删除第一个&
        return url ? url.substring(1) : ''
    },
    /**
     *获取url参数
     *@param {String} string       字符串
     */
    getUrlParam:function(string){
        console.log('获取参数')
        //构造一个含有目标参数的正则表达式对象
        var reg = new RegExp("(^|&)"+ string +"=([^&]*)(&|$)");
        //匹配目标参数
        var r = window.location.search.substr(1).match(reg);
        //返回参数值
        if (r!=null) return unescape(r[2]);
        return null;
    },
    /**
     *返回中英文字符长度
     *@param {String} str       字符串
     *@param {String}           字符个数
     */
    getRealLen:function(str) {
        return str.replace(/[^\x00-\xff]/g, '__').length; //这个把所有双字节的都给匹配进去了
    },
    /**
     *截取字符串
     *@param {String} str       要截取的字符串
     *@param {String} len       要截取的字符个数
     */
    beautySub:function( str, len) {
        var reg = /[\u4e00-\u9fa5]/g,    //专业匹配中文
            slice = str.substring(0,len),
            realen = len - ( ~~( slice.match(reg) && slice.match(reg).length ) );
        return slice.substring(0, realen ? realen : 1);
    },
    /**
     * 处理图片清晰度
     * @param url,rt,lt   图片地址 ,替换数字
     * @return {Boolean}   返回是否加载成功，true代表成功，false代表失败
     */
    filtimg:function(url,rt,lt){
        return url.replace(rt,lt)
    },
    /**
     *获取当前工作室对应的标签
     */
    getWorkType:function(){
        let _url=window.location.href;//'http://caidao.hexun.com/10780870/index';
        _workType=_url.match(/\d+?[\\\/]([a-zA-Z0-9\-\_]+)?(\.html|\?|$)/i);
        if(_workType && _workType.length>1){
            _workType=_workType[1];
        }else{
            _workType='index';
        }
    },
    /**
     *获取老师ID
     *@param
     */
    getTechId: function () {
        let _url=window.location.href;//'http://caidao.hexun.com/10780870/index.html';
            _teachID=_url.match(/hexun\.com[\\\/](\d+)?[\\\/]/i);
        if(_teachID && _teachID.length>1){
            _teachID=_teachID[1];
        }else{
            _teachID = utils.getUrlParam("testid");
        }
        // if(!_teachID)window.location.href=_host.cdHost;
        return true
    },
    /**
     *获取滚动条当前的位置
     */
    getScrollTop:function () {
        var scrollTop = 0;
        if (document.documentElement && document.documentElement.scrollTop) {
            scrollTop = document.documentElement.scrollTop;
        }
        else if (document.body) {
            scrollTop = document.body.scrollTop;
        }
        return scrollTop;
    },
    /**
     *获取当前可视范围的高度
     */
    getClientHeight:function () {
        var clientHeight = 0;
        if (document.body.clientHeight && document.documentElement.clientHeight) {
            clientHeight = Math.min(document.body.clientHeight, document.documentElement.clientHeight);
        }
        else {
            clientHeight = Math.max(document.body.clientHeight, document.documentElement.clientHeight);
        }
        return clientHeight;
    },
    /**
     *获取文档完整的高度
     */
    getScrollHeight:function () {
        return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
    },
    /**
     *判断是否是财道APP
     *@param {bool} return      字符串
     */
    isApp:function(){
        var ua = navigator.userAgent.toLowerCase();
        if(ua.indexOf('hxappid')>0) {
            return true;
        } else {
            return false;
        }
    }
}
utils.getTechId();
utils.getWorkType()
export {utils}