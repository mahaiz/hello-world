<template>
    <div id="loading" :style="{display: loaded?'block':'none'}">
        <img src="//imgcd.hexun.com/teacher/h5/images/loading.gif" alt="">
    </div>
</template>

<script>
    export default {
        name: "loading",
        created:function () {
            this.$emit('loaded')
        }
    }
</script>

<style scoped>

</style>