<!--工作室课程标签:显示课程列表-->
<template>
    
</template>

<script>
    export default {
        name: "lesson"
    }
</script>

<style scoped>
    /*课程*/
    .sectionB{background: #fff;}
    #yykt,#xtkt{
        margin-top: 10px;
    }
    .sectionB2{margin-top: 0px;}
    .sectionB h5{line-height: 50px;position: relative;font-size: 14px;}
    .sectionB h5 a,.sectionB h5 span{display: inline-block;}
    .sectionB h5 span{display: inline-block;line-height: 14px;border-left:solid 1px #ee5050;padding-left: 15px;color: #333;}
    .sectionB h5 a{display: inline-block;float: right;}
    .sectionB h5:after,.cbList:after{ content: '';position: absolute;bottom:-1px;left:0px;width: 200%;height: 1px;border-bottom:#eee solid 1px;
        transform-origin:0 0;transform:scale(0.5,0.5);}
    .sectionB .videoB{ background: #ccc;width:100%;height: 211px;position: relative;}
    .sectionB .videoB2{background: #000; z-index: 9}
    .sectionB .videoB i,.cbList .cb-video i{width: 40px;height: 40px;margin:auto;position: absolute;left:0px;right: 0px;top: 0px;bottom: 0px;}

    .sectionB .courseList{padding: 15px 0;position: relative;border-bottom:#eee solid 1px;}
    .sectionB .courseList dt{position: absolute;left: 0px;top: 15px;}
    .sectionB .courseList dt img{width: 115px;height: 65px;}
    .sectionB .courseList dd{width:100%;box-sizing: border-box;padding-left: 130px;}
    .sectionB .courseList dd h4{width:100%;font-size: 16px;line-height: 16px;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}
    .sectionB .courseList dd time{color: #999;line-height: 38px;height: 38px;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}
    .starbg{margin-right:5px;background: #efefef;width: 80px;height: 13px;}
    .starbg .schedule{
        width: 0%;
        height: 13px;
        background: #ff9500;
    }
    .starbg .schedule .star{
        width: 80px;
        height: 13px;
        background: url(../images/toubing.png) no-repeat;
    }
</style>