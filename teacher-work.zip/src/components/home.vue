<!--工作室首页标签:加载后端html串-->
<template>
    <div class="tab_cont" v-html="htmlData">
    </div>
</template>

<script>

    export default {
        name: "home",
        data:function () {
            return {
                htmlData:'',
                http:this.$getHttpToHttps,
            }
        },
        created(){
        },
        watch: {
        },
        mounted(){
        },
        activated(){
            var _url='adcont',_this=this;
            console.log('httpToHttps=',this.http,this.$getTechId)
            this.$getData('adcont',{'userId':this.$getTechId}).then(function(_data){
                console.log('获得数据：',_data);
                _this.htmlData=_data.data.adversitingInfo.content_h;
                _this.$emit('loaded')
            })
        },
        deactivated(){

        }
    }
</script>

<style scoped>

</style>