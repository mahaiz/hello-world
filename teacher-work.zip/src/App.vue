<template>
  <Teacher></Teacher>
</template>

<script>
import Teacher from './components/index.vue'

export default {
  name: 'app',
  components: {
      Teacher
  }
}
</script>

<style>

  /*组件通用 s*/

  .content{
    background: #fff;
    width: 100%;
    overflow: hidden;
  }
  .content{
    padding-bottom: 50px;
  }
  .courseBox{
    display: none;
    opacity: 0;
    background: #eee;
  }
  /*组件通用 e*/
  /*媒体查询*/
  @media screen and (max-width:640px){

  }
  @media screen and (max-width:320px)
  {/*iphone4*/
    sectionB .courseList dd time {
      font-size: 12px;
      color: #999;
      line-height: 38px;}
    .sectionB .courseList dt img {
      width: 100px;
      height:65px;}
    .sectionB .courseList dd{padding-left: 115px;}
    .sectionB .courseList dd h4{width:100%;font-size: 14px;line-height: 16px;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}
  }
  #tab_cont_index img{width:100%;height:auto;}
  @media screen and (min-width:321px) and (max-width:375px)
  {/*iphone5、iphone5c、iphone5s、iphone6、iphone6plus*/

  }
  @media screen and (min-width:376px) and (max-width:414px)
  {/*iphone5、iphone5c、iphone5s、iphone6、iphone6plus*/

  }
  @media screen and (min-width:415px) and (max-width:860px)
  {/*iphone5、iphone5c、iphone5s、iphone6、iphone6plus*/
    html{font-size:75%;}
  }
</style>
