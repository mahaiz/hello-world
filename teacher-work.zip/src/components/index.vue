<!--工作室主结构:老师介绍-->
<template>
    <div>
        <section class="bg-blue wrap" id="teacherInfo">
            <div class="lef"><img src="http://logo3.tool.hexun.com/d3d40f-150.jpg"></div>
            <div class="mid white">
                <h5><span class="ft16">首席夏立军</span><i class="tg"></i></h5>
                <dl class="clearfix jg infoHide">
                    <dt></dt>
                    <dd>所在机构：和讯公司</dd>
                </dl>
            </div>
            <div class="rig"><a class="attend e4c" data-flog="0">已关注</a></div>
        </section>
        <!--介绍 s-->
        <section class="bg-blue wrap infoHide" style="display: block;">
            <dl class="clearfix zgh">
                <dt class="two"></dt>
                <dd>证券执业资格号：A0030615110001</dd>
            </dl>
            <p class="tag sc"><b>擅长：</b><span>专注短线</span><span>操盘高手</span><span>涨停板王</span></p>
            <p class="infoTxt" title="和讯首席投资顾问，短线实战高手。拥有20多载市场交易经验，曾经作为中央电视台，中央人民广播电视台，北京电视台等多家媒体的客座嘉宾，独创量化精选模型“盈利三部曲”，利用分时技巧完成 “蓄势、冲关、涨停”三步动作短线捕捉涨停。多年来秉承“一切投资从实战出发”的理念，紧随市场热点强势狙击短线，受到广大投资者一致好评！">简介：和讯首席投资顾问，短线实战高手。拥有20多载市场交易经验，曾经作为中央电视台...<a class="gn-a-more" href="#">[更多]</a></p>

        </section>
        <div class="bg-blue gn-navcon">
            <ul class="gn-nav clearfix">
                <li class="gn-left">
                    <span>1.27<i>万</i></span>
                    <p>粉丝数</p>
                </li>
                <li>
                    <span>2504</span>
                    <p>问股回答</p>
                </li>
                <li>
                    <span>829</span>
                    <p>发布文章</p>
                </li>
                <li class="gn-right">
                    <span>28</span>
                    <p>发布课程</p>
                </li>
            </ul>
        </div>
        <p class="bg-blue arrowB"><a class="arrow"></a></p>
        <!--介绍 e-->

        <nav class="bg-white wrap clearfix" id="menu">
            <div class="gn-sec-nav">
                <a href="javascript:;" target="_self" style="display:undefined"><span class="" data-type="index">首页</span></a><a href="javascript:;" target="_self" style="display:undefined"><span class="on" data-type="index">动态</span></a><a href="javascript:;" target="_self" style="display:undefined"><span class="" data-type="course">课程</span></a><a href="javascript:;" target="_self" style="display:undefined"><span  data-type="blog">文章</span></a><a href="javascript:;" target="_self" style="display:undefined"><span data-type="blog">量化</span></a><a href="javascript:;" target="_self" style="display:none"><span class="" data-type="aplan">A股雷达</span></a>
            </div>
            <div class="gn-sec-line"></div>
            <div class="gn-sec-div">
                <a href="javascript:void(0)" class="gn-more-btn"></a>
                <!-- <a href="javascript:void(0)" class="gn-left-btn"></a> -->
            </div>
        </nav>
        <div class="content">
            <div id="loading" style="display: none;">
                <img src="//imgcd.hexun.com/teacher/h5/images/loading.gif" alt="">
            </div>
        </div>
        <!--关注提示框-->
        <div class="gztsBox">
            <div class="gzts">
                <h4>确定要取消对<span></span>的关注吗？</h4>
                <div>
                    <a href="javascript:;" class="yes fl">是</a>
                    <a href="javascript:;" class="fou fl">否</a>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    export default {
        name: "index"
    }
</script>

<style scoped>/*首页*/
.wrap{padding: 0 15px;box-sizing: border-box;}
.wrapL15{padding: 0 0 0 	15px;box-sizing: border-box;}
.bg-blue{ background: #142f5c;}
.bg-white{ background: #fff;}
.bg-ee{ background: #eee;}

    /*关注提示弹窗*/
    .gztsBox{
        width: 100%;
        height: 100%;
        position: fixed;
        background: rgba(0,0,0,.5);
        z-index: 998;
        display: none;
    }
    .gzts{
        position: absolute;
        width: 72%;
        left: 14%;
        top: 35%;
        border-radius: 10px;
        background: #fff;
        font-size: 16px;
    }
    .gzts h4{
        color: #000;
        text-align: center;
        line-height:20px;
        padding: 25px;
        box-sizing: border-box;
    }
    .gzts div{
        width: 100%;
        overflow: hidden;
        text-align: center;
        border-top: 1px solid #D3D3D7;
    }
    .gzts div a{
        line-height: 40px;
    }
    .gzts div a.yes{
        width: 49%;
        border-right: 1px solid #d3d3d7;
        color:#0074ff;
    }.gzts div a.fou{
         width:50%;
         color: #ee5050;
     }
    #teacherInfo{box-sizing:border-box;position: relative;height:84px;}
    #teacherInfo .lef,#teacherInfo .rig{position: absolute;top:12px;}
    #teacherInfo .lef{left:15px;width:56px;height:56px;border-radius: 999px;border:#8c9ab3 solid 2px;overflow: hidden;}
    #teacherInfo .lef img{width:56px;height:56px;}
    #teacherInfo .rig{right: 15px;}
    #teacherInfo .rig a{display: block;width: 90px;height: 35px;line-height: 35px;border-radius:25px;text-align: center;color: #fff;margin-top: 15px;}
    #teacherInfo .rig a.e50{
        background: #EE5050;
    }
    #teacherInfo .rig a.e4c{
        background: #3c4c6c;
    }
    #teacherInfo .mid{padding: 12px 90px 0 69px;}
    #teacherInfo .mid i{display: inline-block;width: 16px;height: 16px;margin:2px 0 0 10px;background: url(../assets/images/icos.png) no-repeat 0 -87px; background-size:25px;vertical-align: top;}
    #teacherInfo .mid i.mj{background-position: 0 -68px;display: none;}
    #teacherInfo .mid i.ls{background-position: 0 -87px;display: none;}
    #teacherInfo .mid i.tg{background-position: 0 -328px;display: none;}
    #teacherInfo .mid h5{padding-top: 10px;vertical-align: top;}
    .infoHide{color: #a2aec1;padding-bottom: 10px;display: none;}
    .infoHide dl{padding-bottom: 10px;}
    .infoHide dl dt,.infoHide dl dd{float: left;line-height: 14px;}
    .infoHide dl dt{width: 12px;height: 14px;background: url(../assets/images/icos.png) no-repeat 0 -129px; background-size:25px;margin-right: 10px;}
    .infoHide dl dt.two{width: 14px;height: 11px; background-position: 0 -149px;    margin-top: 3px;}
    .infoHide .tag b,.infoHide .tag span{display: inline-block;}
    .infoHide .tag span{
        padding: 0 10px;
        height: 24px;
        line-height: 24px;
        border-radius:4px;
        background: rgba(255,255,255, 0.1);
        text-align: center;
        color: #bec4cf;
        margin: 5px 10px 5px 0;
    }
    .infoHide .infoTxt{line-height: 24px;padding-top: 5px;}
    .mask,.mask2,.mask-attend,.mask-edit{display:none;background:rgba(0,0,0,0.7);width: 100%;height: 100%;position: fixed;top: 0px;left:0px;z-index: 998;}
    .arrowB{padding-bottom: 10px;text-align: center;}
    .mask iframe,.mask2 iframe{ z-index: 998; width: 100%; height: 100%; background: none;border:0; }
    .arrowB a{display: inline-block;border-right:solid 2px #fff;border-top:solid 2px #fff;width: 10px;height: 10px;-webkit-transform:rotate(135deg);-webkit-transition:ease-in 0.2s;}
    .arrowB a.arrowUp{-webkit-transform: rotate(-45deg);transition:ease-in 0.2s;margin-bottom: -7px;}

    .disnone{
        display: none;
    }
    .disblock{
        display: block;
    }
    .bb88 {
        color: #44bb88;
    }
    .ee5050 {
        color: #ee5050;
    }
    #loading{
        text-align: center;
        padding: 50px 0;
        vertical-align: middle;
    }
    #loading img{
        width: 32px;
        height: 32px;
    }

    /*20181220  TinaGao -s*/


    .gn-a-more{
        font:14px/24px 'microsoft yahei';
        color: #a2aec1;
    }
    .gn-navcon{
        width:90%;
        padding:0 5%;
    }
    .gn-nav{
        width:100%;
        padding:10px 0 5px;
        border-top:solid 1px rgba(255,255,255,0.20);
    }
    .gn-nav li{
        float: left;
        width:25%;
        color:#fff;
        text-align: center;
    }
    .gn-nav li span{
        font-size: 16px;
        font-family: 'arial';
        color:#fff;
    }
    .gn-nav li span i{
        font-size:12px;
    }
    .gn-nav li p{
        font-size:14px;
        opacity: .7;
    }
    .gn-sec-nav{
        float: left;
        width:85%;
    }
    .gn-sec-line{
        float: left;
        width:2%;
        height: 50px;
        overflow: hidden;
        background: -webkit-linear-gradient(-90deg, rgba(255,255,255,0.00) 0%, rgba(0,0,0,0.06) 100%);
        background: linear-gradient(-90deg, rgba(255,255,255,0.00) 0%, rgba(0,0,0,0.06) 100%);
    }

    .gn-sec-div{
        float: right;
        width: 13%;
        text-align: center;
    }
.gn-a-more{
    font:14px/24px 'microsoft yahei';
    color: #a2aec1;
}
.gn-navcon{
    width:90%;
    padding:0 5%;
}
.gn-nav{
    width:100%;
    padding:10px 0 5px;
    border-top:solid 1px rgba(255,255,255,0.20);
}
.gn-nav li{
    float: left;
    width:25%;
    color:#fff;
    text-align: center;
}
.gn-nav li span{
    font-size: 16px;
    font-family: 'arial';
    color:#fff;
}
.gn-nav li span i{
    font-size:12px;
}
.gn-nav li p{
    font-size:14px;
    opacity: .7;
}
.gn-sec-nav{
    float: left;
    width:85%;
}
.gn-sec-line{
    float: left;
    width:2%;
    height: 50px;
    overflow: hidden;
    background: -webkit-linear-gradient(-90deg, rgba(255,255,255,0.00) 0%, rgba(0,0,0,0.06) 100%);
    background: linear-gradient(-90deg, rgba(255,255,255,0.00) 0%, rgba(0,0,0,0.06) 100%);
}

.gn-sec-div{
    float: right;
    width: 13%;
    text-align: center;
}
#menu{
    margin-bottom: 2.5px;
}
#menu a.gn-more-btn,#menu a.gn-left-btn{
    display:block;
    padding:0;
    margin-top:18px;
    margin-left:14px;
    width: 18px;
    height: 18px;
    background:url(../assets/images/gn-icos.png) no-repeat 0 0rem/1.6rem 26.8rem;
}
#menu a.gn-left-btn{
    background-position: 0 -1.6rem;
    background-size: 1.6rem 26.8rem;
}

#menu{box-sizing: border-box;margin-bottom: 10px;padding: 0;}
    #menu a{display: inline-block;line-height: 50px;text-align: center;padding: 0 5%;}
    #menu a span{display: inline-block;line-height: 50px;}
    #menu a span.on{color: #ee5050;border-bottom:1px solid #ee5050;}
    #menu{
        margin-bottom: 2.5px;
    }
    #menu a.gn-more-btn,#menu a.gn-left-btn{
        display:block;
        padding:0;
        margin-top:18px;
        margin-left:14px;
        width: 18px;
        height: 18px;
        background:url(../assets/images/gn-icos.png) no-repeat 0 0rem/1.6rem 26.8rem;
    }
    #menu a.gn-left-btn{
        background-position: 0 -1.6rem;
        background-size: 1.6rem 26.8rem;
    }
</style>