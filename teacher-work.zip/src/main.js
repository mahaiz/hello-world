import Vue from 'vue'
import App from './App.vue'
import {utils} from './Utils'

Vue.config.productionTip = false;
Vue.use(utils);

new Vue({
    created(){
    },
    mounted(){//检查是否加载httpTohttps
        let _this=this,_httpsEL=$('script[src*="hexun.com/js/httpToHttps.js"]');
        if(window.httpToHttps && window.httpToHttps.https){
            console.log('window.httpToHttps =',window.httpToHttps )
            _this.$setHttpToHttps(window.httpToHttps)
        }else if(_httpsEL.length>0){
            _httpsEL.on('load',function(){
                window.httpToHttps && window.httpToHttps.https && _this.$setHttpToHttps(window.httpToHttps);
            })
        }else {

        }
        if(window.hxcdcommonhead){
            window.hxcdcommonhead.loadUserCenterThen(function(_loadInfo){
                console.log('_loadInfo=',_loadInfo)
                _this.$setLoginInfo(_loadInfo);
            })
        }
        },
  render: h=>h(App)
}).$mount('#app');
